[toc]
### 页面出现横滚
当overflow-x:hidden 和100% 都不生效时
在css文件中添加此段代码
```
    html {
    overflow-y: scroll;
    }

    :root {
    overflow-y: auto;
    overflow-x: hidden;
    }

    :root body {
    position: absolute;
    }

    body {
    width: 100vw;
    overflow: hidden;
    }

```
