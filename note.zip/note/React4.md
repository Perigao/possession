[toc]
# React
## 生命周期
### 挂载后
componentDidMount()
### 更新后
componentDidUpdate()
### 卸载前
componentWillUnmount()
### toLocaleString()
将时间转换成可识别时间
## 计时器案例
```
import { Component } from "react";

class Counter extends Component{
    state = {
        now:new Date(),
        timer:null
    }
    // 挂载后
    componentDidMount(){
        this.start();
        console.log("挂载了")
    }
    // 更新后
    componentDidUpdate(){

    }
    // 卸载前
    componentWillUnmount(){

    }
    // 开始计时
    start(){
        let now;
        let times;
        this.timer = times = setInterval(() => {
            now = new Date()
            this.setState({
                now:now,
                timer : times
            })
        },1000);
    }
    // 停止计时
    stop(){
        clearInterval(this.state.timer);
        this.setState({
            timer:null
        })
    }
    // 点击事件
    handelClick = ()=>{
        if(this.state.timer){
            this.stop()
        }else{
            this.start()
        }
    }
    render(){
        return(
            <div>
                <h2>计时器</h2>
                <p>最新时间：{this.state.now.toLocaleString()}</p>
                <button onClick = {this.handelClick}>
                    {this.state.timer ? "暂停" : "开始"}
                </button>
            </div>
        )
    }
}

export default Counter;
```

## 表格Demo
>reduce 
数据的累加或累减 `{this.state.data.reduce((a,b)=>a+b.bonus,0)}`
* 第一个参数a-总数 =>total
* 第二个参数b-当前值 
* 0-当前a最开始初值 
> map 
用的时候注意一定要绑key值
```
import { Component } from "react";
import './Table.css'
class Table extends Component{
    state = {
        data:[
            {
                score:[80,90,70],
                bonus:500,
                name:"lucy"
            },
            {
                score:[80,90,90],
                bonus:400,
                name:"lily"
            },
            {
                score:[100,100,100],
                bonus:700,
                name:"何盈盈"
            },
            {
                score:[80,50,20],
                bonus:500,
                name:"hyy"
            }
        ]
    }
    sortDate(){
        // 倒序排列
        return this.state.data.sort((a,b)=>b.bonus-a.bonus)
    }
    newTable(){
        // 整体数据降序
        var data = this.sortDate(this.state.data);
        return data.map((item,index)=>{
            return(
                <tr key={index}>
                    {/* 名次 */}
                    <td>{index+1}</td>
                    {/* 名字 */}
                    <td>{item.name}</td>
                    {/* 分数 */}
                    {/* 单独一个表达式箭头后不用再加括号 */}
                    {item.score.map((a,b)=> <td key={b}>{a}</td>)}
                    {/* 总分  */}
                    <td>{item.score.reduce((c,d) => c + d)}</td>
                    {/* 奖金 */}
                    <td>{item.bonus}</td>
                </tr>
            )
        })
    }
    render(){
        return(
            <div>
                <table className = "sell">
                    <thead>
                        <th>名次</th>
                        <th>名字</th>
                        <th colSpan={3}>分数</th>
                        {/* <td ></td>
                        <td></td> */}
                        <th>总分</th>
                        <th>奖金</th>
                    </thead>
                    <tbody>
                        {/* <td>第一名</td>
                        <td>80</td>
                        <td>90</td>
                        <td>100</td>
                        <td>270</td>
                        <td>200</td> */}
                        {this.newTable()}
                        <tr>
                            <td colSpan={6}>奖金总计</td>
                            <td>
                                {/* a-总数 b-当前值 0-当前a最开始初值 */}
                                {this.state.data.reduce((a,b)=>a+b.bonus,0)}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }
}

export default Table;
```
## useState
> Hooks 16.8版本后引入的一个钩子 
> 主要解决：函数组件中数据修改的

* **hooks钩子写在函数组件顶部**
* 可以定义多个钩子
### 小Demo(单个数组)
```
function Demo(){
    let [name,setName] = useState("Lucy");
    let [age,setAge] = useState(10)
    let [address,setAddress] = useState("哈尔滨")
    return(
        <div>
            <p>我的名字：{name}</p>
            <p>我的年龄：{age}岁</p>
            <p>我住在{address}</p>
            <button onClick={()=>{
                setName("Ben")
                setAge(20)
                setAddress("霍格沃兹")
            }}>
                修改
            </button>
        </div>
    )
}
```
### 小Demo(对象)
* 与单个数组不同点在于更改时需要先结构...
```
function Demo(){
    let [user,setUser] = useState({
        name:"LiLi",
        age:18
    })
    return(
        <div>
            <p>My name is {user.name}</p>
            <p>My age is {user.age}</p>
            {/* 与单个数组不同点在于更改时需要先结构... */}
            <button onClick={()=>{
                setUser({...user,name:"Lucy",age:40})
            }}>
                修改
            </button>
        </div>
    )
}
```
## useEffect
* 1.每次组件渲染时 调用 执行一些副作用代码(注意写成箭头函数格式)
//修改会变
```
    useEffect(()=>{
            console.log("haha")
        })
```
* 2.代表生命周期 componentDidMount 挂载前
//只会在页面挂载时执行一次，不会随页面变而变，修改不会变
```
    useEffect(()=>{
            console.log("die")
        },[])
```
* 3.组件卸载前执行 这里返回回调 会在组件卸载前执行
// 处理一些冗余
```
function MainItem({name,age}) {
    useEffect(()=>{
        return (
            // 这里返回回调 会在组件卸载前执行
            // 处理一些冗余
            console.log("卸载组件")
        )
    },[])
    return(
        <div>
            <h1>我的名字：{name}</h1>
            <h2>我的年龄：{age}</h2>
        </div>

    )
}

```

* 4.监听state或者props发生变化 （组件初次渲染也会发生监听事件）
### Demo
```
import { useState,useEffect} from "react";
function Clock({title='北京时间'}){
    let [now,setNow] = useState(new Date());
    
    useEffect(()=>{
        let timer;
        timer = setInterval(()=>{
            setNow(new Date());
        },1000);
        //消掉定时
        return ()=>{
            clearInterval(timer)
        };
    },[])

    return(
        <div>
            <p>
                {title || '当前时间'}:{now.toLocaleString()}
            </p>
        </div>
    )
}
export default Clock;
```

## useMemo
> useMemo类似于计算属性 缓存功效
 一定要判断场景 使用useMemo
```
import { useMemo, useState } from "react";
export default function Test() {
    let [demo, setDemo] = useState(10);
    // let newWord = demo *2
    let newWord = useMemo(() => demo * 2, [demo]);
    return(
        <div>{newWord}</div>
    )
}
```
## useCallBack
>useCallBack 做缓存 缓存一个函数
* props中自带一个children属性 在React中















