[toc]
### 网页页面
* 标准流(文档流)
* 浮动
* 定位
  
#### 定位
> position

##### 1.fixed固定定位
> 相对于祖先元素 不占位脱离了文档流
```
    position: fixed;
```
##### 2.sticky粘性定位
> 占位 不脱离文档流
用作吸顶效果
```
    position: sticky;
    top: 10px;
```
##### 3.static静态定位
> 和普通的一样
```
    position: static;
    top: 150px;
```
##### 4.relative相对定位
> 相对于元素本身 占位但不脱离文档流
```
    position: relative;
    top: 100px;
    left: 150px;
```
##### 5.absolute绝对定位
> 不占位 脱离文档流
> > a.当使用绝对定位时 父级元素中没有使用定位 相对于祖先元素定位(即body)
> > b.当父级元素使用相对定位 则子元素相对于父级进行定位
```
    position: absolute;
    top: 100px;
    left: 150px;
```

### 已知宽高盒子页面居中
#### transform
```
position :absolute
left:50%;
top:50%;
transform:translate(-50%,-50%)
```
#### margin 0 auto
```
position :absolute
left:0;
top:0;
bottom:0;
right:0;
margin:0 auto;
``` 


