[toc]
(./day13)
## 获取元素宽度
offsetWidth
## 获取元素高度
offsetHeight 
## 获取元素距离上级距离
offsetTop 
## 获取元素距离左侧距离
offsetLeft
## 获取滚动条滚动高度
 document.body.scrollTop
 document.documentElement.scrollTop
## 事件
### 点击事件
* onclick    单击
* ondblclick    双击
### 鼠标事件
* onmousedown   按下鼠标时触发事件
* onmouseup    鼠标按下松开时所触发的事件
* onmouseover   当鼠标移动到某对象范围的上方时触发此事件
* onmousemove  鼠标移动时候触发
* onmouseout   鼠标移出时触发
### 键盘事件
* onkeydown  按下键盘按键触发事件
* onkeyup   松开键盘按钮触发事件
* onkeypress  键盘上的某个键被按下并且释放时触发此事件
* keyCode   键盘值
```
input.onkeydown = function(event) {
    console.log(event.keyCode,"触发");

    if(event.keyCode == '13') {
        console.log("当前按键时回车键");
    }
}
```





