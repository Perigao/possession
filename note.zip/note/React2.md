[toc]
# React
## 事件处理
React中 事件处理 onXXX 驼峰命名法 
### 点击事件 onClick
```
let element  = (
                <div>
                    <button onClick={handleClick}>点击按钮</button>
                    {/** <div class="btn" >点击事件</div>*/}
                    <br/>
                    <input type="text" onChange={handleChange} />
                    <form onSubmit={handleSubmit}>
                        <button>提交</button>
                    </form>
                </div>
                    
            )
            ReactDOM.createRoot(document.querySelector("#root")).render(element)
        </script>

```
### 改变事件 onChange

## 组件创建
组件：类组件 函数组件
    函数组件
### 函数组件创建
* 函数组件  首写字母要大写
* null undefined boolean Object无法渲染
```
<script type="text/babel">
        // null undefined boolean Object无法渲染
        function New() {
          return (
            <div>
                <h3>一会考你俩面试题</h3>
                {[1,2,3,4,5]}
                {null}
                {undefined}
                {'helloWorld'}
                {false}
                {true}
                {13456}
                {/**
                    {{aaa:"哈哈哈"}} 无法渲染 报错
                */}
            </div>
          )
        }
        let element = <New/>
        ReactDOM.createRoot(document.querySelector("#root")).render(element);
    </script>
```

#### props 父子传参
* 单项数据流 props 推荐父级向子级传递 只读
```
    <script type="text/babel">
        function Good(props) {
            console.log(props,'父级的内容')
            return (
                <div style={{border:"2px solid #f00",padding:"10px"}}>
                    <p>这是一个父级标签</p>
                    <Day name='图图' age={4}></Day>
                </div>
            )
        }
        function Day(props) {
            console.log(props,'子级的内容')
            return (
                <div style={{border:"2px solid #00f",padding:"10px"}}>
                    <p>这是一个子级标签</p>
                    <p>我的名字叫{props.name}</p>
                    <p>我今年{props.age}岁了</p>
                    <button onClick={()=>{
                        handelClick(props)
                    }}>获取内容</button>
                </div>
            )
        }
        function handelClick(props) {
            console.log(props,'内容')
        }
        let element = <Good/>
        ReactDOM.createRoot(document.querySelector("#root")).render(element);
    </script>
```

### 类组件创建
* 类组件 遵从es6规范 可以修改=>state
* 在类组件中写函数不用加function 直接写名字即可
```
    <script type="text/babel">
      class Vase extends React.Component {
        render() {
          return (
            <div style={{ border: "2px solid #f00", padding: "10px" }}>
              <p>这是一个父级标签</p>
            </div>
          );
        }
      }
      let element = <Vase/>
      ReactDOM.createRoot(document.querySelector("#root")).render(element);
    </script>
```
#### state
* 类组件 state 可以修改数据
> props用于函数组件  state 用于类组件
> 修改使用this.state.***做操作
### 计数器DEMO
```
    <script type="text/babel">
      // 计数器
      class White extends React.Component {
        // 定义初始数值
        state = {
          title: "计数器",
          count: 0,
        };
        // constructor() {
        //     super(props),
        //     state={
        //     }
        // }
        // 数据更新视图未变
        // vue解决方案：Vue.set() this.$set
        // react解决方案:
        handleAdd() {
          this.setState({
            count: this.state.count + 1,
          });
          console.log(this.state, "加法");
        }
        handleReduce = () => {
            console.log(this)
          this.setState({
            count: this.state.count - 1,
          });
        };
        render() {
          return (
            <div>
              <h2>{this.state.title}</h2>
              <p>当前数值:{this.state.count}</p>
              <button onClick={this.handleAdd.bind(this)}>+</button>
              <button onClick={this.handleReduce}>-</button>
            </div>
          );
        }
      }
      let element = <White />;
      ReactDOM.createRoot(document.querySelector("#root")).render(element);
    </script>
```





