[toc]

# JavaScript-Dom   (./day12)
 DOM 文档对象模型 Document Object Model
## 获取元素节点
### 获取id命名的元素
getElementById
`var partOne = document.getElementById("partOne");`
### 获取class命名的元素(数组)
getElementsByClassName
`var btn = document.getElementsByClassName("btn");//获取数组`
### 通过标签名称获取元素
getElementsByTagName
`var inputs = document.getElementsByTagName("input");//获取数组`
### 通过css选择器获取（一个）元素
`var box = document.querySelector("#box");`
### 通过css选择器获取（多个）元素
```
var lis = document.querySelectorAll(".list li");
console.log(lis);
var vase = document.querySelectorAll("#vase li");
console.log(vase);
```
## onload
等所有的东西全部加载完毕，再去执行里面的内容
```
window.onload = function(){
    document.getElementById("main").style.color = "green";
}
```
## transition
过渡效果的css3样式属性
符合输出
* property 规定以什么方式去过渡
* duration 运动的时间（s/ms）
* timing-function 运动的方式
* linear 匀速
* delay 运动何时开始 
  
## 解决行内块元素空白间隙问题
* 让所有行内块元素中间无空格
* float 浮动
## 隐藏
### overflow:hidden
>超出部分隐藏 占位 点击事件无效果
### display
>隐藏 不占位 会对页面产生更改
>>隐藏内容：display: none;
显示内容:display: block;
### opacity
>透明度 占位 点击事件仍会触发
## 鼠标划入划出
* .onmousemove  = function() {}  划入
```
// 鼠标划过
container.onmousemove = function() {
    prev.style.display = 'block';
    next.style.display = 'block';
    clearInterval(timer);
}
```
* .onmouseout = function() {}
```
// 鼠标划出
container.onmouseout = function() {
    prev.style.display = 'none';
    next.style.display = 'none';
    timer = setInterval(function(){
        next.onclick();
    },1000)
}
```
## 选项卡demo 
>**html**
```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            text-decoration: none;
            list-style: none;
        }
        #list{
            overflow: auto;
        }
        #list li{
            float: left;
            width: 180px;
            height: 80px;
            border: 1px solid grey;
            text-align: center;
            line-height: 80px;
        }
        .selected{
            background-color: aqua;
            color: green;
            border-bottom: 2px solid #00f;
        }
        .active{
            display: none;
            width: 724px;
            height: 80px;
            border: 1px solid grey;
            text-align: center;
            line-height: 80px;
        }
        .choose{
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <ul id="list">
            <li class="selected">用户管理</li>
            <li>配置管理</li>
            <li>角色管理</li>
            <li>定时任务补偿</li>
        </ul>
    </div>
    <div class="main">
        <div class="choose active">用户管理</div>
        <div class="active">配置管理</div>
        <div class="active">角色管理</div>
        <div class="active">定时任务补偿</div>
    </div>
    <script src="../js/tab.js"></script>
</body>
</html>
```
>**css**
```
var btn = document.querySelectorAll("#list li");
var content = document.getElementsByClassName("active");
var i;
var j;

for(i = 0;i < btn.length; i++){
    btn[i].index = i;
    btn[i].onclick = function(){
        for(j = 0;j < content.length; j++){
            btn[j].className = ' ';
            content[j].className = 'active';
        }
        this.className = 'selected' ;
        content[this.index].className = "choose active";
    }

}
```



















