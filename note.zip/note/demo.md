[toc]
## 轮播图
### js
```
    var btn = document.getElementsByTagName("li");
    var prev = document.getElementById("prev");
    var next = document.getElementById("next");
    var pictures = document.getElementsByClassName("selected")
    var container = document.getElementById("container");
    var isNow=0;
```
#### 抽取方法
```
    var autoPlay = function(ind){
        for(var i = 0; i < btn.length; i++){
                btn[i].className= ' ';
                pictures[i].className = 'selected';  
        }
        btn[ind].className = 'active';
        pictures[ind].className = 'selected choose';
    }
```
#### 小圆点
```
    for(var i = 0;i < btn.length; i++){
        btn[i].index = i;
        btn[i].onclick =function(){
            isNow = this.index;
            autoPlay(isNow);
        }
    }
```
####  下一页 上一页
```
    next.onclick = function(){
        isNow++;
        console.log(isNow)
        if(isNow > pictures.length-1){
            isNow = 0;
        }
        autoPlay(isNow);
    }
    prev.onclick = function(){
        isNow--;
        if(isNow < 0){
            isNow = pictures.length-1;
        }
        autoPlay(isNow);
    }
```
#### 轮播
```
    var time = setInterval (function(){
        next.onclick();
    },2000)
```
#### 鼠标滑过 鼠标移出
```
    container .onmousemove = function(){
        prev.style.display = 'block';
        next.style.display = 'block';
        clearInterval(time);
    }
    container .onmouseout = function(){
        prev.style.display = 'none';
        next.style.display = 'none';
        time = setInterval(function(){
            next.onclick();
        },1000)
    }
```
## 选项卡
### html
```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            text-decoration: none;
            list-style: none;
        }
        #list{
            overflow: auto;
        }
        #list li{
            float: left;
            width: 180px;
            height: 80px;
            border: 1px solid grey;
            text-align: center;
            line-height: 80px;
        }
        .selected{
            background-color: aqua;
            color: green;
            border-bottom: 2px solid #00f;
        }
        .active{
            display: none;
            width: 724px;
            height: 80px;
            border: 1px solid grey;
            text-align: center;
            line-height: 80px;
        }
        .choose{
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <ul id="list">
            <li class="selected">用户管理</li>
            <li>配置管理</li>
            <li>角色管理</li>
            <li>定时任务补偿</li>
        </ul>
    </div>
    <div class="main">
        <div class="choose active">用户管理</div>
        <div class="active">配置管理</div>
        <div class="active">角色管理</div>
        <div class="active">定时任务补偿</div>
    </div>
    <script src="../js/tab.js"></script>
</body>
</html>
```
### css
```
var btn = document.querySelectorAll("#list li");
var content = document.getElementsByClassName("active");
var i;
var j;

for(i = 0;i < btn.length; i++){
    btn[i].index = i;
    btn[i].onclick = function(){
        for(j = 0;j < content.length; j++){
            btn[j].className = ' ';
            content[j].className = 'active';
        }
        this.className = 'selected' ;
        content[this.index].className = "choose active";
    }

}
```

###
## 奥运五环
### html
```
    <div id="blue"></div>
        <div id="black"></div>
        <div id="red"></div>
        <div id="yellow"></div>
        <div id="green"></div>

        <p id="aa">
            一段文字一段文字一段文字一段文字一段文字一段文字一段文字
        </p>
        <script>
            var aa = document.getElementById("aa");
            aa.onclick = function() {
                console.log("点击")
            }
        </script>
```
### css
```
    * {
        margin: 0;
        padding: 0;
    }
    div {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        border-style: solid;
        border-width: 10px;
        position: absolute;
    }
    div::after {
        content: "";
        position: absolute;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        left: -10px;
        top: -10px;
    }
    #blue {
        border-color: blue;
        /* 定位时 若想让元素层级在前 */
        /* z-index: 999; */
        left: 0;
        top: 0;
    }
    #blue::after {
        border: 10px solid blue;
        z-index: 1;
        /* 透明 */
        border-bottom-color: transparent;
    }
    #black {
        border-color: black;
        /* 定位时 若想让元素层级在前 */
        /* z-index: 999; */
        left: 230px;
        top: 0;
    }
    #black::after {
        border: 10px solid black;
        z-index: 1;
        /* 透明 */
        border-left-color: transparent;
    }

    #red {
        border-color: red;
        /* 定位时 若想让元素层级在前 */
        /* z-index: 999; */
        left: 460px;
        top: 0;
    }
    #red::after {
        border: 10px solid red;
        z-index: 1;
        /* 透明 */
        border-left-color: transparent;
    }
    #yellow {
        border-color: yellow;
        /* 定位时 若想让元素层级在前 */
        left: 117px;
        top: 100px;
    }
    #yellow::after {
        border: 10px solid yellow;
        /* 透明 */
        border-left-color: transparent;
    }
    #green {
        border-color: green;
        /* 定位时 若想让元素层级在前 */
        left: 350px;
        top: 100px;
    }
    #green::after {
        border: 10px solid green;
        /* 透明 */
        
        border-left-color: transparent;
    }
    p {
        margin-top: 500px;
        /* 隐藏 */
        /* opacity: 0; */
        /* display: none; */
        visibility: hidden;
        /* 
            visibility 不会改变页面布局 绑定事件不会生效
        */
    }
```
## 左侧固定 右侧自适应
### **————1margin(不推荐)**
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
            }
            #box1 {
                width: 200px;
                height: 200px;
                background: #00f;
            }
            #box2 {
                height: 200px;
                background: #0f0;
                margin-left: 220px;
                margin-top: -200px;
            }
        </style>
    </head>
    <body>
        <div id="box1"></div>
        <div id="box2"></div>
    </body>
    </html>
```
### **————2浮动**
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
            }
            #box1 {
                width: 200px;
                height: 200px;
                background: #f00;
                float: left;
            }
            #box2 {
                height: 200px;
                background: #ff0;
                margin-left: 210px;
            }
        </style>
    </head>
    <body>
        <div id="box1"></div>
        <div id="box2"></div>
    </body>
    </html>
```
### **————3定位**
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
            }
            #box1 {
                width: 200px;
                height: 200px;
                background: #ff0;
                position: absolute;
            }
            #box2 {
                height: 200px;
                background: #f00;
                margin-left: 210px;
            }
        </style>
    </head>
    <body>
        <div id="box1"></div>
        <div id="box2"></div>
    </body>
    </html>
```
### **————4弹性盒**
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
            }
            body {
                display: flex;
            }
            #box1 {
                width: 200px;
                height: 200px;
                background: #f00;
            }
            #box2 {
                height: 200px;
                background: #00f;
                flex: 1;
            }
        </style>
    </head>
    <body>
        <div id="box1"></div>
        <div id="box2"></div>
    </body>
    </html>
```
## 左侧固定 右侧上中下
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
            }
            #box {
                width: 800px;
                height: 800px;
                background: #eee;
                display: flex;
            }

            #sideBar {
                width: 300px;
                height: 100%;
                background: #0f0;
            }
            #right {
                flex: 1;
                background: #00f;
                margin-left: 10px;
                display: flex;
                flex-direction: column;
            }
            #right #header {
                flex: 1;
                background: #f00;
            }
            #right #content {
                flex: 4;
                background: #ff0;
            }
            #right #footer {
                flex: 1;
                background: pink;
            }
        </style>
    </head>
    <body>
        <div id="box">
            <div id="sideBar"></div>
            <div id="right">
                <div id="header"></div>
                <div id="content"></div>
                <div id="footer"></div>
            </div>
        </div>
    </body>
    </html>
```
## 下落的树叶
### html
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            img {
                position: absolute;
            }
        </style>
    </head>
    <body>
        <script src="../js/6.下落的树叶.js"></script>
    </body>
    </html>
```
### js
```
    // 获取屏幕宽高
    var screenWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var screenHeight = document.documentElement.clientHeight || document.body.clientHeight;


    // 构造函数写属性
    function leaf() {
        // 图片的宽度
        this.width = Math.random() * 100 + 100;
        // 图片距离左侧的距离
        this.newLeft = Math.random() * (screenWidth - this.width);
        // 距离顶部位置
        this.tops = 0;
        // 图片路径的展示
        this.newImg = '../img/' + Math.floor(Math.random() * 4 + 1) + '.png'
    }

    // 原型上写方法
    // 树叶初始状态方法
    leaf.prototype.init = function() {
        // 创建标签
        var imgs = document.createElement("img");
        // imgs元素添加路径
        imgs.src = this.newImg;
        imgs.style.width = this.width + 'px';
        imgs.style.left = this.newLeft + 'px';
        imgs.style.top = this.tops + 'px';
        this.img = imgs;
        document.body.appendChild(imgs);

    }

    // 树叶落下方法
    leaf.prototype.fall = function() {
        setTimeout(function(){
        this.timer = setInterval(function(){
                if(this.img.offsetTop < screenHeight - this.img.offsetHeight) {
                    this.img.style.top = this.img.offsetTop + 10 + 'px';
                } else {
                    clearInterval(this.timer)
                }
            }.bind(this),20)
        }.bind(this),Math.random()*2000)
    }

    var newArr = [];
    for(var i=0; i<30; i++) {
        var leaf1 = new leaf();
        newArr.push(leaf1);
        leaf1.init();
    }

    // document.onclick = function() {
    //     for(var i=0;i<newArr.length;i++) {
    //         newArr[i].fall();
    //     }
    // }
```
## 垂直导航
### html
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                list-style: none;
            }
            h2 {
                width: 300px;
                height: 60px;
                line-height: 60px;
                background: #000;
                color: #fff;
            }
            ul {
                display: none;
            }
        </style>
    </head>
    <body>
        <div id="container">
            <h2>管理区</h2>
            <ul>
                <li>111</li>
                <li>111</li>
                <li>111</li>
            </ul>
            <h2>交流区</h2>
            <ul>
                <li>222</li>
                <li>222</li>
                <li>222</li>
            </ul>
        </div>
        <script src="../js/3.垂直导航.js"></script>
    </body>
    </html>
```
### js
```
    var h2 = document.getElementsByTagName("h2");
    for(var i=0;i<h2.length;i++) {
        h2[i].onclick = function() {
            var uls = this.nextElementSibling;
            console.log(uls)
            if(uls.style.display == 'block') {
                uls.style.display = 'none';
            } else {
                uls.style.display = 'block'
            }
        }
    }
```
## 放大镜
### html
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            *{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            #container{
                position: relative;
            }
            #small{
                width: 400px;
                height: 400px;
                position: relative;
            }
            #small img{
                width: 400px;
                height: 400px;
            
            }
            #big{
                width: 400px;
                height: 400px;
                position: absolute;
                top: 0;
                left: 400px;
                overflow: hidden;
            }
            #big #bigImg{
                width: 800px;
                height: 800px;
                display: none;
                position: absolute;
            }
            #small #drag{
                width: 200px;
                height: 200px;
                background-color: black;
                opacity: 0.3;
                position: absolute;
                top: 0;
                display: none;
            }
        </style>
    </head>
    <body>
        <div id="container">
            <div id="small">
                <img src="../images/1.jpg">
                <div id="drag"></div>
            </div>
            <div id="big">
                <img src="../images/1.jpg" id="bigImg">
            </div>
        </div>
        <script src="../js/magnifier.js"></script>
    </body>
    </html>
```
### js
```
    var small = document.getElementById("small");
    var drag = document.getElementById("drag");
    var big = document.getElementById("big");
    var bigImg = document.getElementById("bigImg");
    //鼠标划入
    small.onmouseover = function () {
        drag.style.display = 'block';
        bigImg.style.display = 'block';
    }
    //鼠标移出
    small.onmouseout = function () {
        drag.style.display = 'none';
        bigImg.style.display = 'none';
    }
    //鼠标移动
    small.onmousemove = function (e) {
        var smallleft = e.clientX - drag.offsetWidth / 2;
        var smalltop = e.clientY - drag.offsetHeight / 2;
        drag.style.left = smallleft + 'px';
        drag.style.top = smalltop + 'px';
        //左边
        if(drag.offsetLeft <= 0){
            drag.style.left = 0;
        }
        //上边
        if(drag.offsetTop <= 0){
            drag.style.top = 0;
        }
        //右边
        //最大距离=small.
        var rightMax=small.offsetWidth - drag.offsetWidth;
        if(drag.offsetLeft >=rightMax){
            drag.style.left = rightMax +'px';
        }
        //下边
        var topMax=small.offsetHeight - drag.offsetHeight;
        if(drag.offsetTop >=topMax){
            drag.style.top = topMax +'px';
        }
        //比例
        var x = smallleft / rightMax;
        var y = smalltop / topMax;
        //求大图
        var bigleftMax = bigImg.offsetWidth - big.offsetWidth;
        // console.log(bigleftMax);
        var bigtopMax = bigImg.offsetHeight - big.offsetHeight;
        // console.log(bigleftMax);
        bigImg.style.left=-(bigleftMax * x  )+'px' ;
        console.log(bigleftMax * x);
        bigImg.style.top=-(bigtopMax * y ) +'px';

    }

```
## 小海豹
### html
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="../css/7.小海豹demo.css">
    </head>
    <body>
        
        <h3>页眉</h3>
        <h3>导航</h3>
        <div id="imgBox"></div>
        <div class="main">
            <div class="left"></div>
            <div class="right"></div>
        </div>
        <h3>页尾</h3>
    </body>
    </html>
```
### css
```
    * {
        margin: 0;
        padding: 0;
    }

    h3 {
        width: 960px;
        height: 50px;
        background: #ccc;
        color: #000;
        text-align: center;
        line-height: 50px;
        margin-bottom: 10px;
    }
    .main {
        width: 960px;
        margin: 10px auto;
        overflow: hidden;
    }

    .left {
        width: 630px;
        height: 300px;
        background: #f00;
        float: left;
    }
    .right {
        width: 320px;
        height: 300px;
        background: #00f;
        float: right;
    }

    #imgBox {
        width: 960px;
        height: 500px;
        background: url("../img/1.jpg");
        background-repeat: no-repeat;
        background-size: cover;
    }

    @media screen and (max-width:480px) {
        #imgBox {
            width: 100%;
            height: 0px;
            padding-top: 58%;
            background: url(../img/3.jpg);
            background-repeat: no-repeat;
            background-size: contain;
        }
        h3 {
            width: 100%;
        }
        .main {
            width: 100%;
        }
        .left {
            width: 100%;
        }
        .right {
            width: 100%;
        }
    }
    @media screen and (min-width:960px) {
        #imgBox {
            width: 100%;
            height: 0px;
            padding-top: 58%;
            background: url(../img/2.jpg);
            background-repeat: no-repeat;
            background-size: contain;
        }
        h3 {
            width: 100%;
        }
        .main {
            width: 100%;
        }
        .left {
            width: 63%;
        }
        .right {
            width: 34%;
        }
    }
```
## 点透事件






