[toc]
# React
## 搭建脚手架步骤
* npm install -g create-react-app
* create-react-app 项目名称
* npx create-react-app 项目名称
* npm start 起服务
* npm run build 打包
* npm test 测试
* npm run eject 移出构建工具

## 组件
### 函数组件
* 写函数组件时要记得抛出
抛出组件：`export default 函数名`
* 之后在主页面即app.js中引入`import Loop from './components/Loop'` (按需引入)
* 最后在body里展示<Loop/>  注意标签要闭合
* 函数传参时记得加花括号{} 
* 传参赋值时如果在函数内直接赋值用等于号
```
    //第一种
    function Vase({name="傻逼"}){
        let element;
        if(name){
            element = <h5>你好,{name}</h5>
        }else{
            element = <h5>给我滚</h5>
        }
        return element
    }
    //第二种
    function Vase({user}){
        let element;
        if(user.name){
            element = <h5>你好,{user.name}</h5>
        }else{
            element = <h5>给我滚</h5>
        }
        return element
    }
    <!-- 主页面接参时 app.js -->
    //引入
    import {Vase} from './components/Vase'
    function App() {
        return (
            <div className="App">
            <header className="App-header">
                <Loop/>
                <Vase user={{name:"给我死"}}/>
            </header>
            </div>
        );
    }
    export default Vase;
```
### 类组件
* 类组件第一步引入`import { Component } from "react";`
* 写类组件时要记得抛出
抛出组件：`export default 类名`
* 之后在主页面即app.js中引入`import 类名 from './components/类名'` (按需引入)
* 最后在body里展示<类名/>  注意标签要闭合
```
import { Component } from "react";

const arr = [1,2,3,4,5,6,7,8];

class Every extends Component {
    state = {
        list:[1,2,3,4,5,6,7,8]
    }
    study(){
        let list = this.state.list;
        let res = [];
        // list.forEach((item,index)=>{
        //     res.push(<li key={index}>{item}</li>)
        // })
        for(var i = 0 ; i < list.length ; i++){
            res.push(list[i])
        }
        return res;
    }
    render(){
        return(
            <div>
                <p>第一个：{arr}</p>
                <p>第二个：{this.state.list}</p>
            <p>第三个</p>
            <ul>
                {this.state.list.map((item)=>
                    <li>{item}</li>
                )}
            </ul>
            <p>第四个</p>
            <p>
                {this.study()}
            </p>
            </div>
        )
    }
}
export default Every;
```
### map
#### map用法
第一种
```
const arr = [1,2,3,4,5,6,7,8];
const newArr = arr.map((item)=>item*3+1);
```
第二种
```
    render(){
        return(
            <ul>
                {this.state.list.map((item)=>
                    <li>{item}</li>
                )}
            </ul>
        )
    }

```