[toc]
# react
## 定义
React:用于构建web与原生交互界面的库

## 区别
> * vue.js => 偏向于html扩展
> * react.js => 偏向于javascript扩展
> 
## 创建方式
### vue:
* 1.直接引入vue第三方库
* 2.vue ui去创建
* 3.vue create 项目名

### React:
通过第三方库引入(三个库的顺序不许更改)
* `<script src="./babel.min.js"></script>`   将jsx转为js
* `<script src="./react.development.js"></script>` react核心库
* `<script src="./react-dom.development.js"></script>`  react中dom操作库

## 将标签渲染到页面中
### root
vue 用 app
react 用 root
### script
` <script type="text/babel"></script>`
type="text/babel"  是在告诉babel库 将jsx转成js
### 步骤
* 1.创建标签
`const snow = <h1>今天下大雪</h1>;`
* 2.获取渲染位置
`const getRoot = document.getElementById("root");`
* 3.将新标签渲染到页面上
`ReactDOM.createRoot`  指定渲染页面
` ReactDOM.createRoot(getRoot).render(snow);`
render 是渲染的内容
### 代码
```
    <div id="root"></div>

    <script type="text/babel">
        //1.创建标签 
      const snow = <h1>今天下大雪</h1>;
        // 2.获取渲染位置
      const getRoot = document.getElementById("root");
        // 3.将新标签渲染到页面上
        // ReactDOM.createRoot(指定渲染页面) 
        // render(渲染的内容)
        ReactDOM.createRoot(getRoot).render(snow);
    </script>
```
 
## 数据渲染
### 动态渲染
* vue 动态渲染 {{}} 模板语法
* react 表达式 {} 可以做运算
#### 定义变量
```
    let rain = '雨天';
    const snow = <h3>明天休息,但是有可能{rain}</h3>;
```
#### true/false
```
     const snow = <h3>明天休息,但是有可能{false + 1 }</h3>;  //结果是2
```
#### 拼接字符串
```
     const snow = <h3>明天休息,但是有可能{false + 1 + 'hello'}</h3>;
```
#### 对象
```
    let userName = {
            fistName:'火',
            lastName:'锅'
        }
     const snow = <h3>明天休息,但是有可能{false + 1 + 'hello' + userName.fistName}</h3>;
```
#### 函数
```
    function getName(userName) {
            return `${userName.fistName} ${userName.lastName}`
        }
        const snow = <h4>{getName(userName)}</h4>;
        const getRoot = document.querySelector("#root");
        ReactDOM.createRoot(getRoot).render(snow);
```
## jsX绑定属性
### 注意
* for => htmlFor
* class => className
* jsx中 所有标签 必须闭合
* jsx中的注释：{/* 这里写注释内容 */}

```
    //首先在style里写样式
    <script>
        let element = <h3 className='title'>你好</h3>;
        //会得到类名为title的样式 呈现样式
        let getRoot = document.getElementById("root");
        ReactDOM.createRoot(getRoot).render(element);
    </script>
```
### for
* label中的for的名称与input框中的id名字相同 就可以实现点击label内容input实现聚焦
*  input中 tabIndex属性可以操控tab键下的顺序
```
        <script type="text/babel">
            // let element = <h3 className='title'>你好</h3>;
            let element = (
                <div>
                    <label htmlFor="same">姓名</label>
                    <input id="same" type="text" placeholder='请输入姓名' tabIndex='1' />
                    <br/>
                    <label htmlFor="age">年龄</label>
                    <input id="age" type="text" placeholder='请输入年龄' tabIndex='3' />
                    <br/>
                    <label htmlFor="address">地址</label>
                    <input id="address" type="text" placeholder='请输入地址' tabIndex='2' />
                    <br/>
                </div>
            )
            let getRoot = document.getElementById("root");
            ReactDOM.createRoot(getRoot).render(element);
        </script>
```
## 绑定样式
### className
* className= '类名'
* className = {'类名'}
### jsX中动态渲染样式
* jsx中 style样式是对象Object格式 不能是字符串格式(两种写法)
```
    let left = {
        width: '200px',
        height: '200px',
        backgroundColor: 'purple',
        color: "#fff"
    }
```
```
    <div style={{
        width:'200px',
        height:'200px',
        backgroundColor:'#ff0',
        color:'#f00'
    }}>右侧盒子</div>
```
* 注释可以用//
* 样式属性若是多单词组成 需要变成驼峰命名法
### 代码
```
    <script type="text/babel">
        // 动态渲染样式
        let newBox = {
            width: '500px',
            height: '500px',
            border: '1px solid #f00',
            margin: '0 auto',
            display: 'flex',
            justifyContent: 'space-between',
            alignItem: 'center'
        }
        let left = {
            width: '200px',
            height: '200px',
            // jsx中动态渲染样式 样式属性若是多单词组成则需要变成驼峰命名法
            backgroundColor: 'purple',
            color: "#fff"
        }
        // let box = <div className={'box'}>我的名字叫图图</div>;
        // 需求：盒子样式： 大盒子居中 小盒子通过弹性盒分别居左居右
        let box = (
            <div style={newBox}>
                <div style={left}>左侧盒子</div>
                <div style={{
                    width:'200px',
                    height:'200px',
                    backgroundColor:'#ff0',
                    color:'#f00'
                }}>右侧盒子</div>
            </div>
        )
        let showPage = document.querySelector("#root");
        ReactDOM.createRoot(showPage).render(box);
    </script>
```


















