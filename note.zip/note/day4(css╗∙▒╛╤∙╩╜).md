[toc]
## CSS基本样式
### 取消标签的默认样式
>* __取消a标签默认样式__
text-decoration: none;

>* __取消无序列表默认样式__
list-style: none;

>* __取消input框点击默认样式__
outline: none;

>* __取消边框__
border: none;
### 鼠标变小手
>:hover
+cursor:pointer
### 圆角
>border-radius

50% 变成圆
左上：border-top-left-radius
右上：border-top-right-radius
左下：border-bottom-left-radius
右下：border-bottom-right-radius
__eg__ :border-bottom-right-radius: 10px;

### 轮廓
> outline:width style color 轮廓


复合属性
outline-width
outline-style
outline-color

### 伪元素
>伪元素 加上content

::after 在后面（位置）
::before 在前面（位置）
css2的语法 :after :before
css3的语法 ::after ::before
**eg** :

    p::after{
        content: "今天天气真好";
        color: #f00;
    }


## CSS语法

### 外边距
>外边距：盒子与盒子的距离
margin 复合属性

一个值 上下左右
两个值 上下 左右
三个值 上 左右 下
四个值 上 右 下 左
margin-top
margin-right
margin-left
margin-bottom

### 内边距
>内边距:盒子与内容的距离
padding 复合属性

一个值 上下左右
两个值 上下 左右
三个值 上 左右 下
四个值 上 右 下 左
padding-top
padding-right
padding-left
padding-bottom


 ### 特殊符号
 * &nbsp;半格
 * &gt; 大于号
 * &lt; 小于号
 * &reg; 商标
  
### 省略号
>超出宽度部分变成省略号
* 不允许换行：white-space: nowrap;
* 溢出隐藏：overflow: hidden;
* 变成省略号：text-overflow: ellipsis;

 ### 块级 行内 行内块元素转换
 * 块级元素 display: block
 * 行内元素 display: inline
 * 行内块元素 display: inline-block

### 盒模型
>标准盒模型：box-sizing:content-box;

width = content(内容宽度) + padding +border
height = content(内容高度) + padding +border

>怪异盒模型(IE盒模型) box-sizing:border-box;

width = content(内容宽度+ padding +border) 
height = content(内容高度+ padding +border) 


### 浮动以及清除浮动的方法
>浮动:float:left/right


为什么使用浮动：因为想让元素在一行显示
添加浮动属性后对浮动前的元素无影响，对浮动后的元素有影响
浮动会**导致元素脱离文档流 不占位**
**缺点**：会导致父元素的高度塌陷

>清除浮动的方法共三种

#### 1.溢出隐藏法：

 在父级盒子上 添加overflow:hidden（隐藏）| auto（自适应）

#### 2.额外标签法：

在与浮动同级上添加一个空盒子，单独添加属性clear:both|none|left|right
```
<div class="empty"></div>
在样式表中：
.empty {
    clear: left
}
```
#### 3.伪元素清浮动

将其添加到浮动的父级元素上
```
<div class="main clearfix">
样式表里：
.clearfix::after {
    content: "";
    display: block;
    clear: both;
 }
 ```


















