[toc]
# JavaScripct基础
> 是一种弱语言
>> 数据决定类型
## js的使用
* 1. 在html页面中添加`<script></script>`标签直接写
```
<script>
    alert("12345")
</script>
```
* 2. 新建一个js文件后在html页面中添加`<script src="路径"></script>`
## 变量
> 声明变量
>> var 名字； 
```
    var vase;
    console.log(vase,'打印内容');
```
> 打印 console.log
>>console.log(vase,'打印内容')

>变量赋值
>>变量名字=赋的值 
```
    vase =1;
    console.log(vase,'打印内容');
```

>变量的声明加赋值
>> 
```
    var a=100;
    console.log(a,'打印内容');
```
## js的类型
> 六种数据类型
### 基本数据类型
#### underfined 未定义类型 存在但是没有值
```
    var a;
    console.log(typeof a);
```
#### number 数字类型 
```
    a=1;
    console.log(typeof a,'赋值后');
```
#### string 字符串类型
```
    a='1'
    console.log(typeof a,'新的赋值');//
```
#### boolean  布尔值 true/false
```
 var bbb=true;
        console.log(typeof bbb,'bbb');
        var bbb=false;
        console.log(typeof bbb,'新的');  
```
#### null 空
#### object
* var ccc=null;    //null 空
* var ccc=[];     //数组
* {}  //对象
```
    var ccc=null;
    console.log(typeof ccc,'ccc');        var ccc=[];
    console.log(typeof ccc,'ccc1');
    var ddd=vase;
    console.log(typeof ddd,'ddd');
```
>con:
#### 总结
>数据类型：六种数据类型
基本数据类型：
>>1，2，3 => Number
'123','4343','' => String
rue/false => boolean
a;b;c => undefined
沒有值 => null (空)
引用数据类型：
            [],{},null => Object
判断数据类型： typeOf
### 变量的命名规则
>1. 变量的命名由英文，数字，$(美元符号)，_（下划线）组成；
>2. 变量的命名首字母由英文，数字，$(美元符号)组成；
>3. 变量的命名不能以关键字命名；
>4. 变量的命名必须严格区分大小写；

### 等于==和赋值=
#### =赋值 
>不进行数据判断
 
#### == 不进行赋值  
>进行数据判断 当类型不同 进行强制转换(转换成同类型)
```
 <script>
    var a = 1;
    var b = 2;
    var c = '';
    var d = '1';
    var f = "999";
    if(a == d) {
        alert("♥等于")
    } else {
        alert("♥不等于")
    }//结果等于

    if(a == f) {
        alert("♥等于")
    } else {
        alert("♥不等于")
    }//结果不等于

    if(d == f) {
        alert("♥等于")
    } else {
        alert("♥不等于")
    }//结果不等于
    </script>
```
```
if(null == undefined){
    alert("♥等于")
} else {
    alert("♥不等于")
}//结果是等于
```
 null包含undefined
#### === 全等 进行判断 不会转换数据类型 
```    
    var a = 1;
    var b = '1';
    if(null === undefined) {
        alert("♥等于")
    } else {
        alert("♥不等于")
        }
```
## 运算符
### 算术运算符
#### 加法
>**1.number + string 拼接**
`console.log(a + '23')` //a=1   结果：123
>**2.string + string  拼接**
`console.log('34'+'56')`// 结果：3456
>**3.true + number true => 1(number)** 
`console.log(true + c)`//结果：11
>**4.true + string true不变** 
·console.log(true + '34')·//结果：true34
>**5.true + false boolean时 true=>1 false=>0** 
`console.log(true + false)` //结果：1
>**6.null + (...)都是...**        
`console.log(null + c)`  // 结果：10    
>**7.undefined + c**        
underfined 无论和谁结果都是：NAN 
#### 减法
>console.log(c-d)//5 在减法运算中 number类型时 正常的减法运算
console.log(c - '2')//8在减法运算中 number string(数字) 进行数据类型换算 可以进行减法运算
console.log(c - '哈哈哈')//NaN 
console.log(c - 'hahaha')//NaN
console.log(c - true)//9
console.log(c - null)//10
console.log(c - undefined)//NaN
#### 乘法(类减法)
>console.log(c * '2')// 20
console.log(c * '哈哈哈')//NaN
console.log(c * 'hahaha')//NaN
console.log(c * d) // 50
console.log(c * false)// 0
console.log(c * null)// 0
console.log(c * undefined)//NaN
#### 除法(类减法)
>console.log(c / '2')//5
console.log(c / 'hahah')//NaN
console.log(c / false)//**Infinity**(无穷)
console.log(c / true)//10
console.log(c / null)//Infinity
console.log(c / undefined)//NaN

### 单目运算符
>* a++先赋值 后自增
>* ++a 先自增 后赋值
>* b-- 先赋值 后自减
>* --b 先自减 后赋值
```
<script>
    var a = 5;
    var b;
    // a++ 先赋值 后自增
    b = a++;
    console.log(b,'b')
    console.log(a,'a')

    var d = 5;
    var c;
    // ++a 先自增 后赋值
    c = ++d;
    console.log(c,'c')
    console.log(d,'d')


    // a= 6 b=5
    a = b--;
    // b-- 先赋值 后自减
    console.log(b,'b')
    console.log(a,'a')

    // a=5 b=4
    b = --a
    // --b 先自减 后赋值
    console.log(b,'b')
    console.log(a,'a')

    </script>
```
### 逻辑运算符
|| 或 只要其中一方是真 则为真 除非都不为真 才是假
&& 和 只有双方都为真 才为真；有一方假 则为假
！ 非 去对方的反之;与等于号同时使用时=>不等于
```
    console.log(5<2 || 5>3)         //true
    console.log(2<10 || 3>1)        //true
    console.log(2>4 || 1>3)         //false

    console.log(2>4 && 4<5)         //false
    console.log(2<4 && 3>5)         // false
    console.log(4>2 && 5>1)         // true

    console.log(!true)              // false
    console.log(!0)                 // true
    console.log(5!=2)               //true

    console.log('abc'-"a")          //NaN
```

### 三元运算符（三目运算符）
判断条件语句 ？ "条件为真时返回内容" : "条件不成立时返回的内容"
```
    var a = 10;
    console.log(a<5?'大于':'小于') 
```
## 语句
>语句由由表达式和运算符组成
### 条件语句
#### if
if 搭配 else使用

    if(执行的表达式) {
        满足该条件时 执行的语句
    } else if（执行的表达式）{
       满足该条件时 执行的语句
    } else {
        不满足条件时 执行的语句
    }
#### switch

    switch(条件语句){
        case 值：
                表达式；
                break;
        case 值：
                表达式；
                break;
                ....
        default:
                默认表达式；
                break；(跳出该循环)
    }

### 循环语句
#### for 
>for(初始化变量；判断条件；执行表达式)

当条件满足时 跳出循环；不满足 一直循环
条件成立才开始循环
#### while
break;  跳出该层循环
continue ; 继续下次循环，结束该层循环
条件成立才开始循环
#### do while
无论条件成立与否 都会执行一次循环

## 弹出框
* alert("内容")//警告框
* prompt("请输入")//提示框
  window.prompt("请输入年级",18)
  prompt（"提示信息"，默认输入框中的值）
* confirm("好的") //确认框

eg1.
```
<script>
        var month = prompt("请输入月份");
        var a = 3;//number
        var b = '3'; //string
        console.log(month,'month')
        console.log(a,'a')
        console.log(b,'b')
        switch(month) {
            case "1":   
            case "3": 
            case "5":
            case "7":
            case "8":
            case "10":
            case "12":
                alert("当前是31天");
                break;
            case "4":
            case "6":
            case "9":
            case "11":
                alert("当前是30天");
                break;
            case "2":
                alert("当前是2月");
                break;
            default:
                alert("输入内容不是数字");
                break;  
        }
</script>
```
**注意输入的要为字符串**

eg2.
```
 <script>
       var year = prompt("请输入年份");
       console.log(year)

     // 除以4 为0 
     // 除以100  余数！=0
     
    if((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
        alert("当前为闰年");
    } else {
        alert("当前为平年");
    }

    </script>
```

## 函数 
> function(声明) 函数名称(注意:函数名必须是英文/数字) {
    代码块
    函数要执行的表达式
}

> 全局变量
> >全局变量可以在整体页面使用

> 局部变量
> > 局部变量是在局部声明使用的变量 全局读不到 
```
var sum = 1;
function f1() {
    console.log(sum,'开始')
    console.log("这是第一个函数");
}
f1();
function f2() {
    document.write("这是第二个函数")
}
f2();

function f3(a,b) {
    // 函数中接受传参 多个参数用逗号隔开
    // 局部变量
    // 局部变量是在局部声明使用的变量 全局读不到 
    sum = a + b;
    console.log(sum,'和')
}
console.log(sum,'最后')
// 函数的传参
// 在调用时 我们需要传参
f3(10,5);

```
## 数组
>生成新的数组
 * var arr3 = []; //空
 * var arr = [1,2,3,4,5,6,7];
 * var arr1 = new Array();  //生成一个空数组
```
    var arr3 = [];
    arr3[0] = '我';
    arr3[1] = '你';
    console.log(arr3);
    var arr = [1,2,3,4,5,6,7];
    console.log(arr);
    // 长度 length
    console.log(arr.length);
    // 生成一个空数组
    var arr1 = new Array();
    console.log(arr1,'arr1');
    var arr2 = [1,'3232','动画设计师',48,9,true];
    console.log(arr2,'arr2');
    console.log(arr2[2]);
    // 下标 名称[下标第几个]
    console.log(arr2[5]);
    for(var i=0;i<arr.length;i++){
        console.log("下标:"+ i)
    }
```
### 数组的方法
#### push 和 pop
* push  向数组中最后的位置添加内容
* pop 删除数组中最后一个未知的内容
```
    var arr=[111,121,131,141,151,161];
    arr.push("000");
    console.log(arr);
    //(7) [111, 121, 131, 141, 151, 161, '000']

    arr.pop();
    console.log(arr);
    //(6) [111, 121, 131, 141, 151, 161]
```
#### shift 和 unshift
* shift 删除数组中第一个元素的位置
* unshift 向数组中第一个位置添加内容
```
    arr.shift();
    console.log(arr);
    //(5) [121, 131, 141, 151, 161]

    arr.unshift("009");
    console.log(arr);
    //(6) ['009', 121, 131, 141, 151, 161]
```
#### join
将数组转换成用逗号隔开的字符串
`console.log(arr.join(),'join');`

#### concat
连接数组
```
    var news=[999,989,979];
    var list=arr.concat(news);
    console.log(list,'list');
    //(9) ['009', 121, 131, 141, 151, 161, 999, 989, 979]
```
#### splice
>2个值： splice(从那个下标开始,删除的个数)
3个值：splice(从那个下标开始,删除的个数,添加的替换内容)

可以改变原数组
```
    var aa=list.splice(2,4,'666','777');
    console.log(aa,'aa');
    //(4) [131, 141, 151, 161]

    console.log(list,'list2');
    //(7) ['009', 121, '666', '777', 999, 989, 979]
```
#### slice
截取数组的值slice()
>1个值: 截取索引位置后的全部值
2个值: 截取到第二值 索引位置的前一个 不包含第二个索引位置

对原数组没影响 
```
    var newList=list.slice(3);
    console.log(list,'list3');
    //(7) ['009', 121, '666', '777', 999, 989, 979]

    console.log(newList,'newList');
    //(4) ['777', 999, 989, 979] 
```
#### reverse 
倒序
```
    var bb = list.reverse();
    console.log(bb,'bb');
```
```
    var ff = [2,3,54,23,122];
    var dd = ff.reverse();
    console.log(dd,'dd');
```
#### toString
强制转换成字符串
将数组转换成由,（逗号）分割的字符串
```
    var cc = list.toString();
    console.log(cc,'cc');
```
```
    list += " ";
```
#### sort
排序  按照Unicode编码排序
>升序排列 a-b   、   降序排列 b-a
```
    var newArr = [23,5,76,199,32,2,78,10];
    newArr.sort(function(c,d) {
        // return 返回值
        return c-d;
    })
    console.log(newArr,'newArr')

```

## 对象
> 生成新的对象
 * var obj2 = new Object();    // 生成新的空对象
 * var obj1 = {};    //创建一个对象 对象的声明
>对象的使用
 *  对象名.属性名 = 属性值
    obj2.name = '我的';
```
// 生成新的空数组
var arr = new Array();
var arr = [];
// 生成新的空对象
var obj2 = new Object();
// var data = new Date();
console.log(data,'data')
obj2.name = '我的';
console.log(obj2,'obj2');
// 创建一个对象 对象的声明
var obj1 = {};
var obj = {
    name: '小郑',
    sex: '女',
    age: '我不告诉你'
}
// 对象的使用
// 对象名.属性名 = 属性值
console.log(obj.name);
console.log(arr);

console.log(typeof arr);//Object
console.log(typeof obj);//Object

var x = new String();        // 把 x 声明为 String 对象
var y = new Number();        // 把 y 声明为 Number 对象
var z = new Boolean();       //	把 z 声明为 Boolean 对象
// 请避免字符串、数值或逻辑对象。他们会增加代码的复杂性并降低执行速度。

console.log(typeof x,'x'); //object
console.log(typeof y,'y'); //object
console.log(typeof z,'z') //object
console.log( x,'x1');   //String
console.log( y,'y1');   //Number
console.log( z,'z1')   //Boolean
```
### Data对象
* getFullYear()
* getMonth()+1
* getDate()
* getHours()
* getMinutes()
* getSeconds()
* getMilliseconds()
* getDay()
* getTime()  时间戳
```
    var date = new Date();

    console.log(date.getFullYear(),'当前的年份');
    console.log(date.getMonth()+1,'月份')
    console.log(date.getDate(),'日')
    console.log(date.getHours(),'小时')
    console.log(date.getMinutes(),'分钟')
    console.log(date.getSeconds(),'秒')
    console.log(date.getMilliseconds(),'毫秒')
    console.log(date.getDay(),'星期')


    console.log(date.getTime(),'获取当前时间的时间戳，也就是毫秒')
```
## 字符串方法
### toUpperCase()
将字符串中所有的字母转为大写
```
    var a = "This is my name";
    var b = a.toUpperCase();
    console.log(b,'toUpperCase');
```
### toLowerCase() 
将字符串中所有字母转为小写
```
    var c = b.toLowerCase();
    console.log(c,'toLowerCase')
```
### concat 
连接字符串
```
    var d = c.concat("你好",a,b);
    console.log(d,'concat');
```
### trim()
消除字符串中前后的空格
```
    var ff = '    hello,world   wo   ';
    var ee = ff.trim();
    console.log(ee,'trim');
```
### indexOf
字符串中指定字符串首次出现的索引下标位置
 长度 length
 ```
    var str = "My name is LiLi,I'm Chinese";
    console.log(str,'原字符串');
    str.indexOf("ese");     //结果是3
    // console.log(str.indexOf("ese")); 
 ```

### lastIndexOf 
字符串中指定字符串最后出现的索引下标位置
```
    var str = "My name is LiLi,I'm Chinese name";
    console.log(str,'原字符串');
    var lastStr = str.lastIndexOf("name");
    console.log(lastStr);     //结果:28
```
### slice 
允许负数截取 从后往前-1开始 从前往后0开始(与substring的区别)
**不会改变原字符串**
>一个值 截取当前索引下标位置到最后的内容
>两个值 截取当前索引下标位置到第二个索引下标位置（不包含第二个索引下标）
```
    var str = "My name is LiLi,I'm Chinese";
    var aa = str.slice(-12,-6);  
    console.log(aa,'slice方法');  //结果: ,I'm C slice方法
```
### substring
**不会改变原字符串**
>一个值 截取当前索引下标位置到最后的内容
> 两个值 截取当前索引下标位置到第二个索引下标位置（不包含第二个索引下标）
```
    var str = "My name is LiLi,I'm Chinese";
    var bb = str.substring(3);
    console.log(bb,'substring方法') //结果：name is LiLi,I'm Chinese
```
### substr 
**不会改变原字符串(与splice区别)**
>第一个值 截取下标的起始索引位置
>第二个值 截取的长度
```
    var str = "My name is LiLi,I'm Chinese";
    var cc = str.substr(3,12);
    console.log(cc,'substr方法')  //结果：name is LiLi
```

### replace
用于指定字符串替换
```
    var str = "My name is LiLi,I'm Chinese";
    var dd = str.replace("name",'WWW');
    console.log(dd,'replace方法')
    console.log(str,'字符串1');//结果：My WWW is LiLi,I'm Chinese
```
### split 
字符串转数组
用逗号隔开字符串
```
    var str = "My name is LiLi,I'm Chinese";
    var ff = str.split(",");
    console.log(ff,"split方法")
```
### chatAt 
返回指定下标的字符
```
    var str = "My name is LiLi,I'm Chinese";
    var gg = str.charAt(16);
    console.log(gg,'chatAt方法') //结果：I
```
![字符串](images/字符串.png)
## 栈内存
>基本数据类型(null number string boolean underfined) 放在栈内存中
```
    // 栈内存
    var a = 1;
    var b = "hahaha";
    var c = true;
```
### 赋值
```
    // 基本数据类型赋值
    var aa =20;
    var bb = aa;
    bb = 15;
    console.log(aa,'aa')
```
## 堆内存
>引用数据类型(object) 放在堆内存中
```
    // 堆内存
    var ddd = {
        name:"LiLi",
        age:"11"
    }
```
### 赋值
```
    // 引用数据类型 堆内存
    var mm = {
        name: '我',
        age: '11'
    };
    var nn = mm;
    nn.name = "你"
    console.log(mm.name)
```
![堆](./images/堆.png)
