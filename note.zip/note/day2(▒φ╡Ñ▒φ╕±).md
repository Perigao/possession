[toc]
## 表单
### form
>form 标签 => 表单
> action 规定提交表单向提交处发送的表单数据（很少使用）
>input 输入框 行内块元素
>属性：
>1.placeholder 默认的提示信息 颜色是灰色
>2.value 值
>3.type
>>text 文本（默认）输入框
>>button 按钮 （按钮名称可以自定义）
>>submit 提交按钮
>>reset 重置按钮
>>radio 单选框 注意：name值必须相同才生效
>>checkbox 复选框（多选框）disabled 禁止选择 >>checked 选中状态
>>password 密码
### 下拉框
select 表单中的控件
option 表单中的选项
select 和 option 共同组成下拉框 缺一不可
selected 默认选中  disabled 禁止选中
**eg**
```
    <option value="1">1</option>
    <option value="2" selected>2</option>
    <option value="3" disabled>3</option>
    <option value="4">4</option>
```
### 文本域
>textarea
rows 行     cols 列
maxlength 可以输入的最大长度

`<textarea cols="15" rows="8" maxlength="10"></textarea>`
## 表格
>table表格标签 双标签
* border 边框 在table中添加
* th 表格的头部
* td 表格的主体
* tr 表格的行
* cellpadding 内容和单元格边框的距离
* cellspacing 边框和边框之间的距离
* caption 标题标签
* align 位置：left（左） center （中间） right(右侧)
* bgcolor 单元格的背景色 不推荐使用
* rowspan 合并行
* colspan 合并列
eg:
```
<table border="1" cellpadding="20">
            <caption>课程表</caption>
            <tr>
                <!-- thead -->
                <th rowspan="2">周一</th>
                <th>周二</th>
                <th>周三</th>
                <th>周四</th>
                <!-- 表头 -->
            </tr>
            <tr>
                <!-- <td bgcolor="red">1</td> -->
                <td colspan="0">2</td>
                <td>3</td>
                <td>4</td>
                <!-- 内容 -->
            </tr>
```






