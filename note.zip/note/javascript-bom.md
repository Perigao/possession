[toc]

# JavaScript-Bom
## JavaScript 组成
>JavaScript：
    >>ECMAScript 核心
    >>BOM 浏览器对象模型
    >>DOM 文档对象模型

**为什么HTML中要使用语义化？**
    1.快速的阅读代码
    2.方便搜索引擎提取重要的信息
* 驼峰命名法：第二个单词的首字母大写
## window对象方法
### 获取id命名的元素
>getElementById 
```
    var btn1 = document.getElementById("btn1");
    var btn2 = document.getElementById("btn2");
```
### 获取class命名的元素
>getElementsByClassName
### 相对于窗口
>scrollTo(x,y) 
### 相对于当前位置
>scrollBy(x,y) 
### 点击事件
>onclick 
`btn1.onclick = function(){}`
### 定时器
`var a = setInterval(function(){},时间)`
### 清除定时器 
>clearInterval()
### 延时器
>setTimeOut() 
### 清除延时器
>clearTimeout() 
### 滚动高度
>1. var scrollTop = document.body.scrollTop ;
>2. document.documentElement.scrollTop;
### DEMO
```
    var btn1 = document.getElementById("btn1");//向下划
    var btn2 = document.getElementById("btn2");//向上划
    var a;
    btn1.onclick = function(){
        // 定时器
        a = setInterval(function(){
            var scrollTop = document.body.scrollTop;
            // console.log(scrollTop)
            if(scrollTop < 1799) {
                scrollBy(0,200);
            } else {
                clearInterval(a);
                window.alert("到底了");
            }
        },500)
        // setInterval(function(){},时间)

    }
    // var btn3 = document.getElementById("btn3");
    // btn3.onclick = function() {
    //     // 清除定时器的方法 clearInterval()
    //     clearInterval(a);
    // }
    btn2.onclick = function() {
        var b = setInterval(function(){
            var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            if(scrollTop > 0) {
                scrollBy(0,-200);
            } else {
                clearInterval(b);
                alert("回到顶部了");
            }
        },1000)
    }
```
## history对象
### 返回history上一个url
>history.back() 
### 进入history下一个url
>history.forward() 
### 跳转页面
>history.go(num)  想跳转哪个页面 就填对应层级数字
## Location
* hash 设置或返回从井号 (#) 开始的 URL（锚）
* host 设置或返回主机名和当前 URL 的端口号
* hostname 设置或返回当前 URL 的主机名
* href 设置或返回完整的 URL
* pathname 设置或返回当前 URL 的路径部分
* port 设置或返回当前 URL 的端口号
* protocol 设置或返回当前 URL 的协议
* search 设置或返回从问号 (?) 开始的 URL（查询部分）
* console.log(location.hash);
## Navigator对象
* appCodeName 返回浏览器的代码名
* appName 返回浏览器的名称
* appVersion 返回浏览器的平台和版本信息
* browserLanguage 返回当前浏览器的语言
* cookieEnabled 返回指明浏览器中是否启用 cookie 的布尔值
* cpuClass 返回浏览器系统的 CPU 等级
* onLine 返回指明系统是否处于脱机模式的布尔值
* platform 返回运行浏览器的操作系统平台
* systemLanguage 返回 OS 使用的默认语言
* userAgent 返回由客户机发送服务器的 user-agent 头部的值
* userLanguage 返回 OS 的自然语言设置
## Math
>document 文档的根节点
>>document.write() 页面输出
>>变量 var a = 1;
>>字面量 1 2 3 4 5 6 true 固定值
### Math.PI   π 常量 
document.write(Math.PI);//π 常量 一个固定的值
### Math.E      常量
document.write(Math.E);// 常量 一个固定的值
### Math.ceil(..)   向上取整
console.log(Math.ceil(2.1));//向上取整
### Math.floor(..)  向下取整
console.log(Math.floor(2.4));//向下取整
### Math.abs(...)  绝对值
console.log(Math.abs(-2.43));//绝对值
### Math.round(...)  四舍五入
console.log(Math.round(2.5));//四舍五入
### Math.random()   随机数
console.log(Math.random()*10);//随机数
### Math.round(Math.random()*10)  十以内整数
console.log(Math.round(Math.random()*10));
### Math.round(Math.random()*(y-x)+x) 生成x到y之间的随机整数
console.log(Math.round(Math.random()*(20-10)+10));
### Math.pow(x,y)  x的y次方
console.log(Math.pow(3,3));// x的y次方
### Math.sqrt(x);//返回x的平方根
console.log(Math.sqrt(9));//返回x的平方根
## isNAN











