[toc]
### CSS引入方式
> 外部样式表引入  link rel="stylesheet" href="地址">

link标签引入
rel 引入页面的关系 
stylesheet 样式表
href 路径地址

> 内部样式表
```
<style>
    div {
    width: 200px;
    height: 200px;
    background: #00f;
    }
</style>
```
> 行内样式（内联样式） 
==行内样式 > 内部样式表 > 外部样式表==

### 垂直导航


### 颜色
> 颜色（十六进制颜色）   rgb颜色

* 红色 #f00  #ff0000   rgb(255,0,0)
* 黄色 #ff0  #ffff00   rgb(255,255,0)
* 绿色 #0f0  #00ff00   rgb(0,255,0)
* 蓝色 #00f  #0000ff   rgb(0,0,255)
* 黑色 #000  #000000   rgb(0,0,0)
* 白色 #fff  #ffffff   rgb(255,255,255)
### 透明度
> opciaty  0-1
>rgba(** ,** ,**,0-1) 
### 常用样式
* 像素 px 
* 宽度 width 
* 高度 height 
* 颜色 color 
* 背景 background 
* 背景色 background-color 
* 背景图片 background-image:url("引入图片路径") 
* 背景平铺 background-repeat:
    no-repeat 不平铺
    repeat-x 横向平铺
    repeat-y 纵向平铺
    repeat 平铺

* 背景尺寸 background-size
cover 全覆盖
contain 等比例放大

* 背景位置 background-position
一个值：同时代表x y轴
两个值的情况：
1.x轴 y轴
2.right/left top/bottom  

*  background 复合属性
background: color image repeat position;

* 字体粗细 
font-weight:
字体变细：100-300 lighter
正常字体: 400-500 normal
字体变粗：600-900 bold bolder

* 字体大小
font-size
浏览器识别最小字体 12px

* 缩放 scale:0~1

* 字体样式
font-style:
italic 倾斜
normal 正常

* 字体格式 font-family
  
* 控制文字横向位置
text-align:
center 居中
left 居左
right 居右

* 行间距:line-height
  
* 文字在盒子内居中
text-align:center;
line-height

* text-indent 文本（缩进）
text-indent:2em;缩进2字符

* 边框
复合属性
border:宽度 样式 颜色;
边框样式 
solid 实线
double 双边框
dashed 虚线
dotted 点线

### 选择器
#### 标签选择器

#### id选择器

> 在body标签内的 格式:id="名字(英文)"
在样式表里   格式:#名字{...}

#### 类选择器
> 在body标签中 格式:class="名字（英文）"
在样式表里   格式：.名字{...}

#### 伪类选择器
> :link 点击前的(初始化状态)

> :visited 点击后的 

> :hover 划过效果

> :

>:first-child 第一个子元素
:last-child 最后一个子元素
:nth-child(数字) 自定义第几个子元素 
>>偶数项 even 2n
奇数项 2n+1 odd


#### 包含选择器（后代选择器）
> 不同级

#### 子类选择器
> 大于号>

#### 群组选择器
> p,span,h2,h3

#### 属性选择器
> 格式：
标签名字[属性="属性值"]{...}

#### 相邻选择器
```
挨着h1的h2标签 
h1+h2 {
    color: #f00;
 }
h2+h3 {
    color: #00f;
}
h3+h3 {
    color: #0ff;
}
```
#### 兄弟选择器
```
h1~h3 {
    color: #00f;
}
h1~h5 {
    color: red;
}
h1~h2 {
    color: #ff0;
} 
h5~span {
    color: aqua;
}
```
#### 伪元素选择器
>::before
::after
### 选择器的优先级及权重
> <table>
    <tr>
        <td>!important </td>
        <td>内联样式（style）</td>
        <td>id选择器 </td>
        <td>类选择器（class）= 伪类选择器 = 属性选择器</td>
        <td>标签选择器=伪元素选择器>通配符选择器</td></tr>
    <tr>
    <td> 正无穷</td>
    <td>1,0,0,0</td>
    <td>0,1,0,0</td>
    <td>0,0,1,0</td>
    <td>0,0,0,1</td>
    <td>0,0,0,0</td>
    </tr>
</table>

