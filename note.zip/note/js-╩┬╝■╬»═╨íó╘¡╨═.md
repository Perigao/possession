[toc]
(/day15)
## 事件委托
>主要作用：用来减少内存消耗，不用处理多次循环绑定
## this指向
* 1.在点击事件中
>当前元素引用谁，this 就指向谁
* 2.在定时器中
>this 指向全局变量 window
* 3.在对象中
>this 指向当前对象的本身
* 4.在函数中
>this 指向window

## 改变this指向的方法
>* 1.call(修改的this指向，参数1 ，参数2)
>* 2.apply(修改的this指向, [参数1，参数2])  //用数组传
>* 3.bind(修改的this指向, 参数1 ，参数2)()
```
    function f1(a,b){
        var sum = a + b ;
        console.log(sum);  // 5
        console.log(this);  // window 
        console.log(this.name);  // underfined
    }
    var obj1 = {
        name : '111',
        sex : 'fe',
    }
    f1(2,3);
    f1.call(obj1,3,3);   
    //改变this指向后  6   {name: '111'}    111
```
**区别：**
1.bind 不会直接调用函数方法 apply 和call 会直接调用函数
2.call 第二个参数开始 需要将传入的参数都逐个列出来
3.apply 第二个参数开始 需要将传入的参数放入数组里

## 原型
原型对象：定义在原型对象下的属性和方法 能被实例化对象所共享了
我们把那些不变的方法直接定义在prototype上
>目标：能够利用原型对象实现方法共享
>>属性 写在构造函数下
方法 写在原型对象下
==构造函数和原型里面的this指向实例化的对象==

每一个构造函数(constructor)  都有一个prototype属性 
prototype（显性的）属性 指向原型对象

### 原型链
访问一个对象的属性时 先去对象的自身属性去找  
* 找不到会通过_proto_(每个实例化对象自带的一个属性（隐性的）)去构造函数上找
* 如果未找到 在Object对象上找 还未找到 返回 undefined 


## 屏幕宽高
宽：
* var screenWidth = document.body.clientWidth  
* var screenWidth = document.documentElement.clientWidth;

高：
* var screenHeight = document.body.clientHeight
* var screenHeight = document.documentElement.clientHeight;










