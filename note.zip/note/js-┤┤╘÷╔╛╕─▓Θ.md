[toc]
## 节点
![文本](images/图片1.png)
innerHTML 包含html标签
innerText 不包含html标签
childNodes[num] 子节点
## 元素上的属性
* id
* className
* value
## 节点遍历
### 第一个子节点
>firstChild (节点名称)
### 最后一个子节点
>lastChild (节点名称)
### 上一个兄弟节点名称
>previousSibling (节点名称)
### 下一个兄弟节点名称
>nextSibling  (节点名称)
### 下一个元素节点
>nextElementSibling 
### 上一个元素节点 如果该节点为第一个节点 则获取值为null
>previousElementSibling 
### 最后一个元素节点
>lastElementChild
### 第一个元素节点
>firstElementChild
### demo
```
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <!-- <script src="../js/2.节点遍历.js"></script> -->
    <p id="main">这是一个p标签</p>
    <div class="box">这是一个盒子</div>
    <h2>
      我的你的
      <br />
      你的我的
      <br />
      1111
    </h2>
    <h3>呜呜呜</h3>
    <ul id="list">
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
    </ul>
    <script>
      var main = document.getElementById("main");
      var box = document.querySelector(".box");
      var h2 = document.querySelector("h2");
      var list = document.getElementById("list");
        console.log(box.nextSibling,'1')
      // firstChild 第一个子节点
      // lastChild 最后一个子节点
      // previousSibling 上一个兄弟节点名称
      // nextSibling 下一个兄弟节点名称
      // nextElementSibling 下一个元素节点
      // previousElementSibling 上一个元素节点 如果该节点为第一个节点 则获取值为null
      // lastElementChild
      // firstElementChild

      //遍历
      function fn2(ele) {
        do {
          ele = ele.previousSibling;
        } while (ele.nodeType != 1);
        return ele;
      }

      function fn1(ele) {
        var a1 = ele.lastChild;
        if (a1.nodeType != 1) {
         return ele = fn2(a1);
        } else {
          return ele;
        }
      }
      console.log(fn1(list));
    </script>
  </body>
</html>
```
## 创 增 删 改 插
### 创建元素
>document.createElement()
```
    var a = document.createElement("span");
    console.log(a);
    a.innerHTML = '新的元素';
    console.log(a);   //结果：<span>新的元素</span>
```
### 插入
>参数2.insertBefore(参数1，参数2)；
>>参数1 要插入的当前元素
>>参数2 项参数2中添加参数一的内容

`first.insertBefore(a,first[0])`
### 添加
>appendChild(传一个值即可)
```
    ul.appendChild(li);
    console.log(ul);
    box.appendChild(ul);
```
### 删除
>removeChild () (单个节点)
>remove()      (删除整个节点 )

`    box.removeChild(ul);`
### 替换
>replaceChild(新节点,旧节点);

`box.replaceChild(h2,first);`

## 事件冒泡
由内向外触发操作
>阻止事件冒泡方法：
>>1.event.stopPropagation();
>>2.event.cancelBubble = true;

```
    box1.onclick = function(event) {
        console.log("第一个盒子");
        event.stopPropagation();
    }

    box2.onclick = function(event) {
        console.log("第二个盒子");
        event.stopPropagation();
    }
    box3.onclick = function(event) {
        console.log("第三个盒子");
        // IE浏览器阻止事件冒泡方法
        event.cancelBubble = true;
    }
```
## 事件捕获
由外向内触发操作
**先捕获 后冒泡**
```
    // 事件捕获
    box1.addEventListener('click',function(){
        console.log(this,'box1');
    },true)

    box2.addEventListener('click',function(){
        console.log(this,'box2');
    },true)

    // 事件冒泡
    box3.addEventListener('click',function(){
        console.log(this,'box3');
    },false)

    box4.addEventListener('click',function(){
        console.log(this,'box4');
    },false)
```

## 添加监听事件
>addEventListener 
>>1.要执行的事件 字符串格式
2.执行的函数方法
3.触发类型 false(事件冒泡) true（事件捕获）
```
    box1.addEventListener("click",function(event){
        console.log("第一个盒子");
        event.stopPropagation();
    },false);

    box2.addEventListener("click",function(event){
        console.log("第二个盒子");
        event.stopPropagation();
    },false);

    box3.addEventListener("click",function(event){
        console.log("第三个盒子");
        event.cancelBubble = true;
    },false);
```
## 事件默认行为
> 取消事件的默认行为
>> 1.event.preventDefault();
2.event.returnValue = false;  // 适用于IE浏览器
```
    var a = document.querySelector("a");
    a.onclick = function(event) {
        console.log("123");
        // 取消事件的默认行为
        event.preventDefault();
        // 适用于IE浏览器
        // event.returnValue = false;
    }
```

## 事件源 
事件的源头  **target**
```
    var box1 = document.getElementById("box1");
    var box2 = document.getElementById("box2");

    box1.onclick = function(event){
        console.log(event.target,'box1');
    }

    box2.onclick = function(event){
        console.log(event.target,'box2');
        event.stopPropagation();
    }
```
## 事件流
>W3C规定的(万维网联盟)
DOM事件流：事件捕获阶段 目标阶段 事件冒泡阶段

var box1 = document.getElementById("box1");
var box2 = document.getElementById("box2");
var box3 = document.getElementById("box3");
var box4 = document.getElementById("box4");





// removeEventListener（参数1，参数2，参数3）













